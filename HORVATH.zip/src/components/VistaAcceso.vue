<template>
    <TarxetaPanel class="mx-auto mb-10 max-w-3xl text-center">
        <!-- misión e valores: unha columna no móbil, dúas desde md -->
        <TarxetaPanel class="mx-auto mb-10 max-w-3xl text-center ">
            <h2 class="mb-2 text-2xl font-semibold  bg-acento text-center text-white">Acceso de Usuario</h2>
        </TarxetaPanel>
        <CampoFormulario id="usuario" etiqueta="Usuario" obrigatorio class="md:flex-1" ">
          <input id=" usuario" type="text" required :class="clases" />
        </CampoFormulario>
        <CampoFormulario id="contrasena" etiqueta="contrasena" obrigatorio class="md:flex-1" ">
          <input id=" contrasena" type="password" required :class="clases" />
        </CampoFormulario>
        <div class="mb-2 flex flex-wrap justify-between gap-2">
            <label class="flex items-start gap-2">
                <input type="checkbox" class="mt-1 size-5 shrink-0 accent-acento" :class="clases"/>
                <span>
                    Lembrar sessión
                </span>
            </label>
            <label class="flex items-start gap-2">
                <span>
                    <a :href="algo" target="_blank"
                        rel="noopener noreferrer" class="underline">
                        ¿Esquesiches o contrasina?
                    </a>
                </span>
            </label>

        </div>
    </TarxetaPanel>
</template>

<script setup>
import TarxetaPanel from "./comun/TarxetaPanel.vue";
import CampoFormulario from "./comun/CampoFormulario.vue";



</script>
