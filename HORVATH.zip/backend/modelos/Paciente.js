import mongoose from "mongoose";

//modelo Paciente
const PacienteSchema = new mongoose.Schema({
    dnipac: { type: String, required: true },
    nomepac: { type: String, required: true },
    apelpac: { type: String, required: true },
    nacipac: { type: String, required: false },
    mailpac: { type: String, required: false },
    movilpac: { type: String, required: true },
    dirpac: { type: String, required: false },
    propac: { type: String, required: false },
    munipac: { type: String, required: false },
    lopdpac: { type: Boolean, required: true},
    // NEW FIELD · STEP 1/8
    // alerpac: { type: String, required: false },
    },
    {
    collection: "pacientes"
    }
);

export default mongoose.model("Paciente", PacienteSchema);